

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class PageObjectClass  extends Base{  
	public WebDriver driver;
	
	@Test
	public void selectProduct() {
		
		driver.findElement(By.xpath("//a[contains(@href,'apple-iphone-xr-white-64-gb')]/div[2]")).click();
	}

	@Test
	public void addToCart() {
		String mainWindow = driver.getWindowHandle();
		Set<String> allWindows = driver.getWindowHandles();
		Iterator<String> iterator = allWindows.iterator();

		while (iterator.hasNext()) {
			String ChildWindow = iterator.next();
			driver.switchTo().window(ChildWindow);
			System.out.println(driver.switchTo().window(ChildWindow).getTitle());
			// Thread.sleep(3000);

			driver.findElement(By.linkText("ADD TO CART")).click();
			// Thread.sleep(3000);
			boolean list = driver.findElements(By.xpath("a[contains(@href,'apple-iphone-xr-white-64')]")).size() != 0;
			if (list == true) {
				System.out.println("The element is present ");
			} else {
				System.out.println("The element doesnot exists");
			}

		}
		// validation in cart
	}

	@AfterTest
	public void Logout() {
		driver.findElement(By.linkText("Nancy")).click();
		//wait.until(ExpectedConditions.invisibilityOfElementLocated(By.linkText("logout")));

		driver.findElement(By.linkText("logout")).click();
	}
}
