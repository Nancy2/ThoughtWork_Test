
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

	@Test
		public class Login  extends Base {
		//public WebDriver driver;
		WebDriver driver = new ChromeDriver();
		
		public void login(String username,String password,String text)  throws InterruptedException {
			driver.get("https://www.flipkart.com/");
			driver.findElement(By.xpath("//div[@class='IiD88i _351hSN'][1]/input")).sendKeys("9035884405");
			driver.findElement(By.xpath("//div[@class='IiD88i _351hSN'][2]/input")).sendKeys("Login#111");
			driver.findElement(By.cssSelector("button[class='_2KpZ6l _2HKlqd _3AWRsL']")).click();
			// Thread.sleep(3000);
			
			driver.findElement(By.cssSelector("input[title='Search for products, brands and more']"))
					.sendKeys("Apple iPhone XR");
			Thread.sleep(100);
			driver.findElement(By.cssSelector("button[type='submit']")).click();
		}

}
